package com.tokendemo.model;

import java.util.List;

public class AuthResponse {
	private String token;
	private List<String> roles;
	private String userName;
	private String tempCookies;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public String getTempCookies() {
		return tempCookies;
	}

	public void setTempCookies(String tempCookies) {
		this.tempCookies = tempCookies;
	}
	
	
}
