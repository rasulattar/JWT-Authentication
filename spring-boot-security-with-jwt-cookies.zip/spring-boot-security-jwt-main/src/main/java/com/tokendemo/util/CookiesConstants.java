package com.tokendemo.util;

public class CookiesConstants {
	
	public static final String WC_ACTIVEPOINTER = "";
	public static final boolean WC_SESSION_ESTABLISHED = true;
	public static final String WC_AUTHENTICATION_ID = "WC_AUTHENTICATION_ ID";
	public static final String WC_USERACTIVITY_ID = "WC_USERACTIVITY_ID";
	public static final String WC_PERSISTENT = "WC_PERSISTENT";

}
