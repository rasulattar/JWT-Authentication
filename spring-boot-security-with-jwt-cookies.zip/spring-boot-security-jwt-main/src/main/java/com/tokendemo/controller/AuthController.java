package com.tokendemo.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tokendemo.dao.RoleRepository;
import com.tokendemo.dao.UserRepository;
import com.tokendemo.model.AuthResponse;
import com.tokendemo.model.CustomUserBean;
import com.tokendemo.model.Role;
import com.tokendemo.model.Roles;
import com.tokendemo.model.SignupRequest;
import com.tokendemo.model.User;
import com.tokendemo.security.JwtTokenUtil;

import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@CrossOrigin(origins="http://localhost:4200") 
@RequestMapping("/auth")
public class AuthController extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Autowired
	UserRepository userRepository;
	@Autowired
	RoleRepository roleRepository;
	@Autowired
	PasswordEncoder encoder;
	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	JwtTokenUtil jwtTokenUtil;
	
	@Value("${jwttoken.expiration}")
	private long jwtTokenExpiration;
	
	@SuppressWarnings("unused")
	@PostMapping("/login")
	public ResponseEntity<?> userLogin(@Valid @RequestBody User user, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AuthController -- userLogin");
		
		
		
		Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(user.getUserName(), user.getPassword()));
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String token = jwtTokenUtil.generateJwtToken(authentication);
		CustomUserBean userBean = (CustomUserBean) authentication.getPrincipal();		
		List<String> roles = userBean.getAuthorities().stream()
									 .map(auth -> auth.getAuthority())
									 .collect(Collectors.toList());
		
		AuthResponse authResponse = new AuthResponse();
		
		authResponse.setUserName(user.getUserName());
		authResponse.setRoles(roles);
		authResponse.setToken(token);
		
		Cookie[] cookies = request.getCookies();
    	String userName = Strings.EMPTY;
    	String sessionID = Strings.EMPTY;
		if (cookies != null) {
			for(Cookie cookie : cookies){
	    		if(cookie.getName().equals("userName")) {
	    			userName = cookie.getValue();
	    		}
	    		if(cookie.getName().equals("JSESSIONID")) {
	    			sessionID = cookie.getValue();
	    		}
	    		
	    		//below attributes are optional
	    		/*cookie.setPath("/"); 
	    		cookie.setHttpOnly(true);
	    		cookie.setDomain("");
	    		cookie.setSecure(true);*/
	    		
	    		cookie.setMaxAge((int)jwtTokenExpiration);
	    		response.addCookie(cookie);
	    	}
		} else {
			//need to put actual value instead of harcoded in double quotation
			Cookie wc_activepointer = new Cookie("WC_ACTIVEPOINTER", Base64.getEncoder().encodeToString(("en" + 150).getBytes()));
			wc_activepointer.setMaxAge((int)jwtTokenExpiration);
			response.addCookie(wc_activepointer);
			//need to put actual value instead of harcoded in double quotation
			Cookie wc_session_establised = new Cookie("WC_SESSION_ESTABLISHED", Boolean.TRUE.toString());
			wc_session_establised.setMaxAge((int)jwtTokenExpiration);
			response.addCookie(wc_session_establised);
			
			//need to put actual value instead of harcoded in double quotation
			Cookie wc_authentication_id = new Cookie("WC_AUTHENTICATION_ID", Base64.getEncoder().encodeToString((user.getUserName() + SignatureAlgorithm.HS512 + ("SessionKey" + user.getUserName() + "timestamp")).getBytes()));
			wc_authentication_id.setMaxAge((int)jwtTokenExpiration);
			response.addCookie(wc_authentication_id);
			
			//need to put actual value instead of harcoded in double quotation
			Cookie wc_user_activity_id = new Cookie("WC_USERACTIVITY_ID", Base64.getEncoder().encodeToString((token + wc_activepointer + "authenticationFlag" + "loginTime" + "ExpiryTime" + "ExpiresUserId" + "preExpiryURL" + "forUserId" + "activeOrgId").getBytes()));
			wc_user_activity_id.setMaxAge((int)jwtTokenExpiration);
			response.addCookie(wc_user_activity_id);
			
			//need to put actual value instead of harcoded in double quotation
			Cookie wc_persistent = new Cookie("WC_PERSISTENT", Base64.getEncoder().encodeToString((user.getUserName() + "en" + "PersonalizationIdif(Yes)" + "currencyDependsOnStoreIdFromSession").getBytes()));
			wc_persistent.setMaxAge((int)jwtTokenExpiration);
			response.addCookie(wc_persistent);
			
			//below attributes are optional
    		/*cookie.setPath("/"); 
    		cookie.setHttpOnly(true);
    		cookie.setDomain("");
    		cookie.setSecure(true);*/
		}
		return ResponseEntity.ok(authResponse);
	}
	
	public static Cookie deleteCookie(String strCookieName, String strPath) {
	    Cookie cookie = new Cookie(strCookieName, "");
	    cookie.setMaxAge(0);
	    cookie.setPath(strPath);

	    return cookie;
	}
		
	@PostMapping("/signup")
	public ResponseEntity<?> userSignup(@Valid @RequestBody SignupRequest signupRequest) {
		if(userRepository.existsByUserName(signupRequest.getUserName())){
			return ResponseEntity.badRequest().body("Username is already taken");
		}
		if(userRepository.existsByEmail(signupRequest.getEmail())){
			return ResponseEntity.badRequest().body("Email is already taken");
		}
		User user = new User();
		Set<Role> roles = new HashSet<>();
		user.setUserName(signupRequest.getUserName());
		user.setEmail(signupRequest.getEmail());
		user.setPassword(encoder.encode(signupRequest.getPassword()));
		//System.out.println("Encoded password--- " + user.getPassword());
		String[] roleArr = signupRequest.getRoles();
		
		if(roleArr == null) {
			roles.add(roleRepository.findByRoleName(Roles.ROLE_USER).get());
		}
		for(String role: roleArr) {
			switch(role.toLowerCase()) {
				case "admin":
					roles.add(roleRepository.findByRoleName(Roles.ROLE_ADMIN).get());
					break;
				case "user":
					roles.add(roleRepository.findByRoleName(Roles.ROLE_USER).get());
					break;	
				default:
					return ResponseEntity.badRequest().body("Specified role not found");
			}
		}
		user.setRoles(roles);
		userRepository.save(user);
		return ResponseEntity.ok("User signed up successfully");
	}
	
}
